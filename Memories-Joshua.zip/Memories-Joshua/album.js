new Vue({
  el: "#app",
  data() {
    return {
      isOpenedTop: true,
      items: [
        {
          img1: "images/her.jpg",
          img2: "images/her2.jpg",
          img3: "images/her1.jpg",
          title: "Marajah",
          isOpen: false,
        },
        {
          img1: "images/me.jpg",
          img2: "images/me1.jpg",
          img3: "images/me2.jpg",
          title: "Joshua",
          isOpen: false,
        },
        {
          img1: "images/us.jpg",
          img2: "images/us1.jpg",
          img3: "images/us2.jpg",
          title: "Us",
          isOpen: false,
        },
        {
          img1: "images/aquarium1.jpg",
          img2: "images/aquarium2.jpg",
          img3: "images/aquarium3.jpg",
          title: "AQUARIUM",
          isOpen: false,
        },
        {
          img1: "images/aurora1.jpg",
          img2: "images/aurora2.jpg",
          img3: "images/aurora3.jpg",
          title: "AURORA",
          isOpen: false,
        },
        {
          img1: "images/sky1.jpg",
          img2: "images/sky2.jpg",
          img3: "images/sky3.jpg",
          title: "SKY",
          isOpen: false,
        },
      ],
    };
  },
  methods: {
    topOpen() {
      this.isOpenedTop = !this.isOpenedTop;
    },

    open(idx, isOpen) {
      if (this.isOpenedTop) {
        this.items[idx].isOpen = !isOpen;
      }
    },

    reset() {
      this.items.forEach((item) => (item.isOpen = false));
      this.isOpenedTop = false;
    },
  },
});
